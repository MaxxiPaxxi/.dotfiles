import Distribution.Simple
main = defaultMainWithHooks autoconfUserHooks
